# Pertinent Questions Plugin - Beta Release
Note: The plugin is in beta release. A full public release will be coming shortly and will be announced via the ProjectBubbleBurst newsletter:
- https://projectbubbleburst.substack.com/

Please sign up to show your support.

The Plugin is available for download here: https://github.com/bubblebursterb/pertinent-questions/releases and can be installed using the BRAT Obsidian plugin

## Video Tutorials
- Coming Soon

### Video Descriptions
- Coming Soon

## Initial Question Tranche
An initial tranche of questions for use with the plugin is also available with the videos above. In future, all Question tranches will be announced/released via the newsletter:
- https://projectbubbleburst.substack.com/

## Support Us
- https://ProjectBubbleBurst.com/Support+Us

